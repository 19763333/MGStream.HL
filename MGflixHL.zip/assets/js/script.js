
const apiKey = "0c2435c6e5e96da810abe6c4dd2c077b";
const content = document.getElementById("content");
const searchInput = document.getElementById("searchInput");

async function fetchMovies(query = "") {
  const url = query
    ? `https://api.themoviedb.org/3/search/movie?api_key=${apiKey}&query=${query}`
    : `https://api.themoviedb.org/3/movie/popular?api_key=${apiKey}`;

  const res = await fetch(url);
  const data = await res.json();
  content.innerHTML = "";
  data.results.forEach(movie => {
    const card = document.createElement("div");
    card.className = "card";
    card.innerHTML = `
      <img src="https://image.tmdb.org/t/p/w500${movie.poster_path}" />
      <h3>${movie.title}</h3>
    `;
    card.onclick = () => openPlayer(movie.title);
    content.appendChild(card);
  });
}

function openPlayer(title) {
  const videoUrl = "https://test-streams.mux.dev/x36xhzz/x36xhzz.m3u8";
  const modal = document.getElementById("playerModal");
  const player = document.getElementById("videoPlayer");
  player.src = videoUrl;
  modal.style.display = "block";
}

document.querySelector(".close").onclick = () => {
  document.getElementById("playerModal").style.display = "none";
  document.getElementById("videoPlayer").pause();
};

window.onclick = e => {
  const modal = document.getElementById("playerModal");
  if (e.target === modal) {
    modal.style.display = "none";
    document.getElementById("videoPlayer").pause();
  }
};

searchInput.addEventListener("input", () => {
  fetchMovies(searchInput.value);
});

fetchMovies();
